package com.example.googlenav;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import androidx.fragment.app.FragmentContainerView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;


public class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.ViewHolder> {

    private List<String> mData;
    private LayoutInflater mInflater;
    private ViewPager2 viewPager2;
    FragmentContainerView viewPager_fragment;

    ViewPagerAdapter(Context context, List<String> data, ViewPager2 viewPager2) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
        this.viewPager2 = viewPager2;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.viewpager_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String dataItem = mData.get(position);
        //this is where the text data item is being set
        // change this to adapter_viewPager
        holder.myTextView.setText(dataItem);

        //View view_test =  inflater.inflate(R.layout.settings_tab2, container, false);
        //holder.myViewPager_fragment.addView(R.layout.settings_tab2);

        //holder.myViewPager_fragment.addView()

    }


    @Override
    public int getItemCount() {
        return mData.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView myTextView;
        FragmentContainerView myViewPager_fragment;

        ViewHolder(View itemView) {
            super(itemView);
            //this is where the text data item is being received
            //change this to adapter_viewPager
            myTextView = itemView.findViewById(R.id.tvTitle);
            myViewPager_fragment = itemView.findViewById(R.id.viewPager_fragment);


        }
    }

}