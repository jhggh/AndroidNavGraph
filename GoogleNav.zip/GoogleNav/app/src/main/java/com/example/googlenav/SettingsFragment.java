package com.example.googlenav;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends Fragment {

    public View view;
    private ViewPager2 viewPager; //The pager widget, which handles animation and allows swiping horizontally
    private TabLayout tabLayout;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_settings, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tabLayout = view.findViewById(R.id.tabLayout);
        viewPager = view.findViewById(R.id.viewPager);

        List<String> list = new ArrayList<>();
        list.add("First Screen");
        list.add("Second Screen");
        list.add("Third Screen");
        list.add("Fourth Screen");

        viewPager.setAdapter(new ViewPagerAdapter(view.getContext(), list, viewPager));

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText("OBJECT " + (position + 1))
        ).attach();

//        //Here is another way to add tab items
//        TabLayout.Tab tab1 = tabLayout.newTab().setText("Tab1");
//        tabLayout.addTab(tab1,0);
//
//        TabLayout.Tab tab2 = tabLayout.newTab().setText("Tab2");
//        tabLayout.addTab(tab2,1);
//
//        TabLayout.Tab tab3 = tabLayout.newTab().setText("Tab3");
//        tabLayout.addTab(tab3,2);






    }


}