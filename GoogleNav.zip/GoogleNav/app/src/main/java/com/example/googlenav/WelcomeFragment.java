package com.example.googlenav;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class WelcomeFragment extends Fragment {

    View view;
    TextView tv_username, tv_password;
    Button btn_ok;
    String username, password;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.fragment_welcome, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tv_username = view.findViewById(R.id.tv_username);
        tv_password = view.findViewById(R.id.tv_password);
        btn_ok = view.findViewById(R.id.btn_ok);

        String username = WelcomeFragmentArgs.fromBundle(getArguments()).getUsername();
        String password = WelcomeFragmentArgs.fromBundle(getArguments()).getPassword();

        tv_username.setText(username);
        tv_password.setText(password);

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NavDirections action = WelcomeFragmentDirections.actionWelcomeFragmentToHomeFragment();
                Navigation.findNavController(view).navigate(action);

            }
        });
    }
}